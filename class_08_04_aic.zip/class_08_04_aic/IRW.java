package class_08_04_aic;

public interface IRW {
    int readInt();
    void writeln(String mes);
    void write(String s);
}
