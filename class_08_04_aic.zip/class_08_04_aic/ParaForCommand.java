package class_08_04_aic;

import java.util.List;

public class ParaForCommand {

	private List<Student> students;

	public ParaForCommand(List<Student> students) {
		this.students = students;
	}

	public List<Student> getStudents() {
		return students;
	}
}
